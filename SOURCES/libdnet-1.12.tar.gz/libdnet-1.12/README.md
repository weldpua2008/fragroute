IPv6-enabled version of libdnet
===============================

[Original code](http://code.google.com/p/libdnet/)
