/*
 * randutil.h
 *
 * Copyright (c) 2001 Dug Song <dugsong@monkey.org>
 *
 * $Id: randutil.h,v 1.1 2002/04/07 22:55:20 dugsong Exp $
 */

#ifndef RANDUTIL_H
#define RANDUTIL_H

void		 rand_strset(rand_t *r, void *buf, size_t len);

#endif /* RANDUTIL_H */
